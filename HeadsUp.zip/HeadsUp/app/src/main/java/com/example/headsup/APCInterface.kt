package com.example.headsup

import retrofit2.Call
import retrofit2.http.*

interface APCInterface {

    @Headers("Content-Type: application/json")
    @GET("/celebrities/")

    fun GetCelebrities(): Call<Celebrity>


    @Headers("Content-Type: application/json")
    @POST("/celebrities/")
    fun addCelebrity(@Body userData: Celebrity): Call<Celebrity>

    @Headers("Content-Type: application/json")
    @PUT("/celebrities/{pk}")
    fun updateCelebrity(@Path("pk")id: Int, @Body userData:Celebrity):Call<Celebrity>

    @Headers("Content-Type: application/json")
    @DELETE("/celebrities/{pk}")
    fun deleteCelebrity(@Path("pk") id: Int ): Call<Void>
}
