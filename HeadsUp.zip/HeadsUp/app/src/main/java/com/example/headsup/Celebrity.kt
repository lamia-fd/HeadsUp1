package com.example.headsup

import com.google.gson.annotations.SerializedName

class Celebrity(name:String?=null, taboo1:String? = null,  taboo2:String?= null, taboo3:String?=null, pk:Int?=null) {


   /* @SerializedName("taboo1")
    var taboo1:String? = null

    @SerializedName("taboo2")
    var taboo2:String?= null

    @SerializedName("name")
    var name:String?=null

    @SerializedName("taboo3")
    var taboo3:String?=null

    @SerializedName("pk")
    var pk:Int?=null*/


}