package com.example.headsup

import android.app.ProgressDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_new_celebrity.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class newCelebrity : AppCompatActivity() {

    lateinit var add:Button
    private val apiInterface by lazy { APIClient().getClient()?.create(APCInterface::class.java) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_celebrity)

        add=findViewById(R.id.button3)

        var name=findViewById<TextView>(R.id.nameText)

        var taboo1Text=findViewById<TextView>(R.id.taboo1Text)

        var taboo2Text=findViewById<TextView>(R.id.taboo2Text)

        var taboo3Text=findViewById<TextView>(R.id.taboo3Text)

print(name.text.toString())
        add.setOnClickListener {

            print(name.text.toString())


            var f = Celebrity(
                "name.text.toString()" ,
           "     taboo1Text.text.toString()",
              "  taboo2Text.text.toString()" ,
                "taboo3Text.text.toString()",11)

            addNEW(f, onResult = {
                name.setText("")
                taboo1Text.setText("")
                taboo2Text.setText("")
                taboo3Text.setText("")
                Toast.makeText(applicationContext, "Save Success!", Toast.LENGTH_SHORT).show();
            })


        }

    }




    private fun addNEW(userData: Celebrity, onResult: (Celebrity) -> Unit) {

        ///val apiInterface = APIClient().getClient()?.create(APCInterface::class.java)

        val progressDialog = ProgressDialog(this@newCelebrity)
        progressDialog.setMessage("Please wait")
        progressDialog.show()

        if (apiInterface != null) {
            apiInterface!!.addCelebrity(userData).enqueue(object : Callback<Celebrity> {
                override fun onResponse(
                    call: Call<Celebrity>,
                    response: Response<Celebrity>
                ) {
                    response.body()?.let { onResult(it) }
                    progressDialog.dismiss()
                }

                override fun onFailure(call: Call<Celebrity>, t: Throwable) {
                   // onResult(null)
                    Toast.makeText(applicationContext, "Error!", Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss()

                }
            })
        }

    }
}