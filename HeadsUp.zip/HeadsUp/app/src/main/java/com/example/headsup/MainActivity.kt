package com.example.headsup

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    var newRecipe=ArrayList<String>()
    val apiInterface = APIClient().getClient()?.create(APCInterface::class.java)
    lateinit var name:EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val rv=findViewById<RecyclerView>(R.id.rvMain)
        rv.adapter= recycler(newRecipe)
        rv.layoutManager= LinearLayoutManager(this)
         name=findViewById<EditText>(R.id.nameText)


    }

    fun AddCelebrity(view: android.view.View) {

        intent = Intent(applicationContext, newCelebrity::class.java)
        startActivity(intent)

    }

    fun UpdateAndDelete(view: android.view.View) {
        intent = Intent(applicationContext, UpdateDelete::class.java)
       // intent.putExtra("name",name)
        startActivity(intent)
    }
}